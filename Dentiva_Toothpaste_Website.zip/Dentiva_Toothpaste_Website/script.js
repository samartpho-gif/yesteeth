// ==========================================
// YES TEETH - MAIN JAVASCRIPT
// File: script.js
// ==========================================

// Google Apps Script Web App URL (รับคำสั่งซื้อ)
const APPS_SCRIPT_URL =
  'https://script.google.com/macros/s/AKfycbwGi_0Q06i4KlUhwAlHmGrd5YQWNmIdTZYZVDnNcn0OTZwMv-vU4fTtPGjROw4ra0yelA/exec';

// CSV URL สำหรับหน้า Admin
// ใส่ URL เผยแพร่เป็น CSV จาก Google Sheets ในภายหลัง
const CSV_URL = 'ใส่_CSV_URL_ภายหลัง';

// แปลงตัวเลขเป็นรูปแบบเงินบาท
const money = value =>
  Number(value || 0).toLocaleString('th-TH');

// ป้องกันข้อความ HTML แทรกในหน้าเว็บ
function escapeHTML(value) {
  return String(value ?? '').replace(/[&<>"']/g, char => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  })[char]);
}

// ==========================================
// 1. PRODUCT PAGE
// ต้องมี element id="product-list" และ id="filter-bar"
// products.json ต้องเป็น JSON array
// ==========================================

async function initProducts() {
  const list = document.getElementById('product-list');
  const bar = document.getElementById('filter-bar');

  if (!list || !bar) return;

  try {
    const response = await fetch('products.json');
    if (!response.ok) throw new Error('ไม่พบไฟล์ products.json');

    const products = await response.json();
    if (!Array.isArray(products)) {
      throw new Error('รูปแบบ products.json ต้องเป็น Array');
    }

    const labels = {
      cavity: 'ยาสีฟันฟันผุ',
      whitening: 'ยาสีฟันฟันขาว',
      fresh: 'Fresh',
      sweet: 'Sweet'
    };

    // สร้างปุ่มกรองจากหมวดหมู่และ mood ที่มีอยู่ใน products.json
    const categories = [
      ...new Set(
        products.flatMap(product => [
          product.category,
          product.type,
          product.mood
        ]).filter(Boolean).map(String)
      )
    ];

    bar.innerHTML = `
      <button class="filter-btn active" data-cat="all">ทั้งหมด</button>
      ${categories.map(category => `
        <button class="filter-btn" data-cat="${escapeHTML(category)}">
          ${escapeHTML(labels[category] || category)}
        </button>
      `).join('')}
    `;

    function render(items) {
      if (!items.length) {
        list.innerHTML = '<p>ไม่พบสินค้าในหมวดหมู่นี้</p>';
        return;
      }

      list.innerHTML = items.map(product => {
        const name = escapeHTML(product.name || 'yes teeth');
        const size = escapeHTML(product.size || '');
        const description = escapeHTML(product.description || '');
        const image = escapeHTML(product.image || '');
        const price = Number(product.price || 0);
        const itemValue = encodeURIComponent(
          `${product.name || 'yes teeth'} ${product.size || ''}`.trim()
        );

        return `
          <article class="product-card">
            <img src="${image}" alt="${name}" loading="lazy">
            <div class="eyebrow">YES TEETH</div>
            <h3>${name}</h3>
            <div class="meta">${size}</div>
            <p class="desc">${description}</p>
            <div class="price-row">
              <span class="price">฿${money(price)}</span>
              <a class="btn btn-small"
                 href="order.html?item=${itemValue}&price=${encodeURIComponent(price)}">
                สั่งซื้อ
              </a>
            </div>
          </article>
        `;
      }).join('');
    }

    bar.addEventListener('click', event => {
      const button = event.target.closest('[data-cat]');
      if (!button) return;

      bar.querySelectorAll('[data-cat]').forEach(item => {
        item.classList.toggle('active', item === button);
      });

      const selected = button.dataset.cat;
      const filtered = products.filter(product => {
        if (selected === 'all') return true;
        return [product.category, product.type, product.mood]
          .some(value => String(value) === selected);
      });

      render(filtered);
    });

    const params = new URLSearchParams(location.search);
    const requestedCategory =
      params.get('mood') || params.get('category');

    if (requestedCategory) {
      const button = [...bar.querySelectorAll('[data-cat]')]
        .find(item => item.dataset.cat === requestedCategory);

      if (button) {
        button.click();
      } else {
        render(products);
      }
    } else {
      render(products);
    }
  } catch (error) {
    console.error('Product loading error:', error);
    list.textContent =
      'ไม่สามารถโหลดข้อมูลสินค้าได้ กรุณาตรวจสอบไฟล์ products.json';
  }
}

// ==========================================
// 2. ORDER PAGE
// ต้องมี form id="orderForm" และ input IDs:
// customerName, contact, items, total, note
// ==========================================

function initOrder() {
  const form = document.getElementById('orderForm');
  if (!form) return;

  const params = new URLSearchParams(location.search);
  const itemInput = document.getElementById('items');
  const totalInput = document.getElementById('total');

  if (itemInput && params.has('item')) {
    itemInput.value = params.get('item');
  }

  if (totalInput && params.has('price')) {
    totalInput.value = params.get('price');
  }

  form.addEventListener('submit', async event => {
    event.preventDefault();

    if (!form.reportValidity()) return;

    const getValue = id =>
      document.getElementById(id)?.value?.trim() || '';

    const payload = {
      customerName: getValue('customerName'),
      contact: getValue('contact'),
      items: getValue('items'),
      total: getValue('total'),
      note: getValue('note')
    };

    const submitButton = form.querySelector('[type="submit"]');
    const originalButtonText = submitButton?.textContent;

    if (submitButton) {
      submitButton.disabled = true;
      submitButton.textContent = 'กำลังส่งคำสั่งซื้อ...';
    }

    try {
      // ใช้ text/plain เพื่อลดปัญหา CORS preflight กับ Apps Script
      // no-cors ทำให้ browser อ่าน response กลับมาไม่ได้
      await fetch(APPS_SCRIPT_URL, {
        method: 'POST',
        mode: 'no-cors',
        headers: {
          'Content-Type': 'text/plain;charset=utf-8'
        },
        body: JSON.stringify(payload)
      });

      // หมายเหตุ: no-cors ยืนยันได้เพียงว่าส่ง request ออกไป
      // ไม่สามารถตรวจสอบผลการบันทึกใน Google Sheets จาก browser ได้
      window.location.href = 'thankyou.html';
    } catch (error) {
      console.error('Order submission error:', error);
      alert('ส่งคำสั่งซื้อไม่สำเร็จ กรุณาตรวจสอบอินเทอร์เน็ตแล้วลองอีกครั้ง');

      if (submitButton) {
        submitButton.disabled = false;
        submitButton.textContent = originalButtonText || 'ยืนยันสั่งซื้อ';
      }
    }
  });
}

// ==========================================
// 3. ADMIN PAGE
// CSV_URL ต้องเป็นลิงก์ CSV ที่เข้าถึงได้
// ตารางต้องมี id="ordersTable" และมี <tbody>
// ==========================================

function parseCSV(text) {
  const rows = [];
  let row = [];
  let value = '';
  let quoted = false;

  for (let index = 0; index < text.length; index++) {
    const char = text[index];

    if (char === '"') {
      if (quoted && text[index + 1] === '"') {
        value += '"';
        index++;
      } else {
        quoted = !quoted;
      }
    } else if (char === ',' && !quoted) {
      row.push(value);
      value = '';
    } else if ((char === '\n' || char === '\r') && !quoted) {
      if (char === '\r' && text[index + 1] === '\n') index++;
      row.push(value);
      if (row.some(cell => cell !== '')) rows.push(row);
      row = [];
      value = '';
    } else {
      value += char;
    }
  }

  row.push(value);
  if (row.some(cell => cell !== '')) rows.push(row);
  return rows;
}

async function initAdmin() {
  const tbody = document.querySelector('#ordersTable tbody');
  if (!tbody) return;

  if (!CSV_URL.startsWith('https://') ||
      CSV_URL === 'ใส่_CSV_URL_ภายหลัง') {
    tbody.innerHTML =
      '<tr><td colspan="6">ยังไม่ได้ตั้งค่า CSV_URL</td></tr>';
    return;
  }

  try {
    const response = await fetch(CSV_URL);
    if (!response.ok) throw new Error('โหลด CSV ไม่สำเร็จ');

    const rows = parseCSV(await response.text());
    const orders = rows.slice(1).reverse();

    if (!orders.length) {
      tbody.innerHTML =
        '<tr><td colspan="6">ยังไม่มีรายการสั่งซื้อ</td></tr>';
      return;
    }

    tbody.innerHTML = orders.map(row => `
      <tr>
        ${row.slice(0, 6).map(cell =>
          `<td>${escapeHTML(cell)}</td>`
        ).join('')}
      </tr>
    `).join('');
  } catch (error) {
    console.error('Admin loading error:', error);
    tbody.innerHTML =
      '<tr><td colspan="6">ไม่สามารถโหลดข้อมูลออเดอร์ได้</td></tr>';
  }
}

// ==========================================
// 4. INITIALIZE
// ==========================================

document.addEventListener('DOMContentLoaded', () => {
  initProducts();
  initOrder();
  initAdmin();
});
